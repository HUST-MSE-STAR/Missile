#ifndef BSP_LASER_H
#define BSP_LASER_H

#include "main.h"

extern void laser_on(void);
extern void laser_off(void);
bool_t BUTTEN_TRIG_PIN(void);
void power_init(void);
#endif
