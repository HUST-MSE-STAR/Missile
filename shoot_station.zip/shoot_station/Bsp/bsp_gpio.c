#include "bsp_gpio.h"

void laser_on(void)
{
   HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13, GPIO_PIN_SET);
}
void laser_off(void)
{
   HAL_GPIO_WritePin(GPIOG, GPIO_PIN_13, GPIO_PIN_RESET);
}
bool_t BUTTEN_TRIG_PIN(void)
{
  return 	HAL_GPIO_ReadPin(GPIOF, GPIO_PIN_1);
}

void power_init(void)
{
	HAL_GPIO_WritePin( GPIOH, POWER1_CTRL_Pin|POWER2_CTRL_Pin|POWER3_CTRL_Pin|POWER4_CTRL_Pin, GPIO_PIN_SET);
}






