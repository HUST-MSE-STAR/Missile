#include "bsp_pwm.h"

extern TIM_HandleTypeDef htim8;

void pwm_start(void)
{
	HAL_TIM_PWM_Start(&htim8,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim8,TIM_CHANNEL_2);	
}

void servo_pwm_set(uint16_t pwm)
{
	__HAL_TIM_SetCompare(&htim8, TIM_CHANNEL_2, pwm);
	__HAL_TIM_SetCompare(&htim8, TIM_CHANNEL_1, pwm);
}








