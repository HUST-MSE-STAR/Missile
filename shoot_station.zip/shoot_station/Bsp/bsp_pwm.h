#ifndef BSP_PWM_H
#define BSP_PWM_H

#include "main.h"

void pwm_start(void);
void servo_pwm_set(uint16_t pwm);



#endif
