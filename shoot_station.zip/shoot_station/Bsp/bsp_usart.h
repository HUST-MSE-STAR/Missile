#ifndef BSP_USART_H
#define BSP_USART_H

#include "main.h"

//void usart1_rx_dma_init(uint8_t *rx1_buf, uint16_t dma_buf_num);
extern void usart1_rx_dma_init(uint8_t *rx1_buf, uint8_t *rx2_buf, uint16_t dma_buf_num);
extern void usart6_rx_dma_init(uint8_t *rx1_buf, uint8_t *rx2_buf, uint16_t dma_buf_num);
#endif















