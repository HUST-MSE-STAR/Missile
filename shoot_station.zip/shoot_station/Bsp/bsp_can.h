#ifndef BSP_CAN_H
#define BSP_CAN_H

#include "main.h"

extern void can_filter_init(void);

#endif

