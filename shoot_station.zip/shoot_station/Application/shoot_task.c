#include "shoot_task.h"
#include "stdlib.h"
#include "string.h"

#define servo_pull    servo_pwm_set(850)
#define servo_release servo_pwm_set(500)

shoot_control_t shoot_control;          //�������


void shoot_init(void)
{
	//ң����ָ��
	shoot_control.shoot_rc = get_remote_control_point();
	//���ָ��
	shoot_control.trigger_measure = get_gimbal_motor_measure_point(1);
	shoot_control.shoot_measure = get_gimbal_motor_measure_point(0);
	shoot_control.yaw_motor = get_yaw_gimbal_motor_measure_point();
	//��ʼ��PID
	pid_init(&shoot_control.trigger_motor_pid, 8, 0.000, 0, 5000,10000);
	pid_init(&shoot_control.shoot_pid, 15, 0, 0, 5000,10000);
	pid_init(&shoot_control.yaw_ecd_pid, 1.2, 0.000001, 0, 5,100);
	pid_init(&shoot_control.yaw_speed_pid, 200, 0, 0, 3000,20000);
	//��Ҫ����ʵ�ʵ���
	ramp_init(&shoot_control.pull_shoot_ramp, 5000, 0);
	shoot_control.shoot_mode = SHOOT_STOP;
	
	shoot_control.yaw_ecd_set = 6722;
}

void shoot_task(void const * argument)
{
    //��̨��ʼ��	
	shoot_init();		
	while(1)
	{
	  shoot_control_loop();
		vTaskDelay(1);
	}	
	
}

void shoot_control_loop(void)
{
	
	if(shoot_control.shoot_rc->sw2 == 1 && shoot_control.shoot_mode == SHOOT_STOP)
	{ 
		servo_release;                               //����ſ�
		shoot_control.shoot_mode = SHOOT_READY;
		shoot_control.trigger_speed_set = 0.0f;
	}
	else if(shoot_control.shoot_rc->sw2 == 3 && shoot_control.shoot_mode == SHOOT_READY)
	{
		servo_pull;                                 //�������
		shoot_bullet_control();                     //���̵��ת��ָ���Ƕ�
		
	}
	else if(shoot_control.shoot_rc->sw2 == 2 && shoot_control.shoot_mode == SHOOT_BULLET)
	{
		servo_release;                                 //����ɿ�/
		shoot_control.trigger_speed_set = 0.0f;        
	}
	
	{
		static fp32 add_yaw_angle;
		add_yaw_angle = -shoot_control.shoot_rc->ch3 * 0.001;
		shoot_control.yaw_ecd_set = shoot_control.yaw_ecd_set + add_yaw_angle;
		ecd_limit(shoot_control.yaw_ecd_set);
		if(shoot_control.yaw_ecd_set - shoot_control.yaw_motor->ecd > 4096)
			shoot_control.yaw_ecd_set -=8192;
		else if(shoot_control.yaw_ecd_set - shoot_control.yaw_motor->ecd < -4096)
			shoot_control.yaw_ecd_set +=8192;
 
		shoot_control.yaw_speed_set = pid_calc(&shoot_control.yaw_ecd_pid, shoot_control.yaw_ecd_set, shoot_control.yaw_motor->ecd);
		shoot_control.yaw_current = pid_calc(&shoot_control.yaw_speed_pid, shoot_control.yaw_speed_set, shoot_control.yaw_motor->speed_rpm);
	}
  
	if(shoot_control.shoot_rc->sw1 == 1) //���ϲ����رշ���ܣ�ģʽ��ʼ��
	{
		
	CAN_cmd_gimbal_1234(0, 0, 0, 0);	
	CAN_cmd_gimbal_5678(0, 0, shoot_control.yaw_current, 0);
		
	servo_release;	
	shoot_control.shoot_mode = SHOOT_STOP;	
		
	}
	else if(shoot_control.shoot_rc->sw1 != 1) //���������
	{
	shoot_control.shoot_speed_set = shoot_control.shoot_rc->wheel / 660.0 *2000;			
	shoot_control.shoot_current = pid_calc(&shoot_control.shoot_pid, shoot_control.shoot_speed_set, shoot_control.shoot_measure->speed_rpm);
	shoot_control.trigger_current = pid_calc(&shoot_control.trigger_motor_pid, shoot_control.trigger_speed_set, shoot_control.trigger_measure->speed_rpm);

  CAN_cmd_gimbal_1234(shoot_control.shoot_current, shoot_control.trigger_current, 0, 0);
	CAN_cmd_gimbal_5678(0, 0, shoot_control.yaw_current, 0);
	}
}

void shoot_bullet_control(void)
{
	shoot_control.trigger_ecd = shoot_control.trigger_measure->round_cnt * 8192 + shoot_control.trigger_measure->ecd;
	if (shoot_control.move_flag == 0)
	{
			//ÿ�β��� 1/4PI�ĽǶ�
		shoot_control.trigger_ecd_set = shoot_control.trigger_ecd + PI_THREE;
		shoot_control.move_flag = 1;
	}	
	//����Ƕ��ж�
  if(shoot_control.trigger_ecd_set - shoot_control.trigger_ecd > 100)
	{
			//û����һֱ������ת�ٶ�
			shoot_control.trigger_speed_set = TRIGGER_SPEED;
	}
	else
	{
		//�Ƕȵ���ָ���Ƕ�  ���ͣת  ģʽ�л�
		shoot_control.move_flag = 0;
		shoot_control.trigger_speed_set = 0;
		shoot_control.shoot_mode = SHOOT_BULLET;
	}	
	
}

void trigger_motor_turn_back(void)
{
	//��תʱ���ж�
	if( shoot_control.block_time < 1000)
	{
		shoot_control.shoot_speed_set = SHOOT_SPEED;
	}	
	else
	{
		//�ﵽ����λ�ú󣬵��ͣת������۽���ģʽ�л�
		shoot_control.shoot_speed_set = 0;
		shoot_control.block_time = 0;
		servo_pull;
    shoot_control.shoot_mode = SHOOT_READY;       
	}		
	//����ٶ�С��5����0.7�룬���ж�Ϊ��ת
	if(abs(shoot_control.shoot_measure->speed_rpm) < 5 && shoot_control.block_time < 1000)
	{
			shoot_control.block_time++;
	}	
  	
}

int16_t ecd_limit(int16_t ecd)
{
	if(ecd>8191)
	{
		ecd -=8192;
	  return ecd;
	}
	else if(ecd<0)
	{
		ecd +=8192;
	  return ecd;			
	}
	else 
		return ecd;
}

