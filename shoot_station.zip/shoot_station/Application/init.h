#ifndef INIT_H
#define INIT_H

#include "main.h"
#include "cmsis_os.h"

void hw_init(void);
void task_init(void);

#endif




