#ifndef CAN_RECEIVE_H
#define CAN_RECEIVE_H

#include "main.h"
#include "bsp_can.h"

#define GIMBAL_CAN hcan1
#define CHASSIS_CAN hcan2
//������͵�id
typedef enum
{
	CAN_COMMUNICATION_ID = 0X00A,
	
	CAN_CHASSIS_ALL_ID = 0x200,
	CAN_GIMBAL_ALL_ID = 0x1FF,
	
  CAN_3508_L1_ID = 0x201,
  CAN_3508_L2_ID = 0x202,
  CAN_3508_R1_ID = 0x203,
  CAN_3508_R2_ID = 0x204,
	
	CAN_2006_L_ID = 0X200+5,
	CAN_2006_R_ID = 0X200+6,
	
	CAN_6020_YAW_ID = 0X204+3,
	CAN_6020_PITCH_ID = 0X204+4,
} can_msg_id_e;

typedef struct
{
	uint16_t ecd;
	int16_t speed_rpm;
	int16_t given_current;
	uint8_t temperate;
	int16_t last_ecd;
	int16_t  round_cnt;
} motor_measure_t;

typedef struct
{
	int16_t chassis_vx;
	int16_t chassis_vy;
	int16_t chassis_wz;
}chassis_control_t;

void CAN_cmd_gimbal_1234(int16_t motor1, int16_t motor2, int16_t motor3, int16_t motor4);
void CAN_cmd_gimbal_5678(int16_t shoot1, int16_t shoot2, int16_t yaw, int16_t pitch);
void CAN2_cmd_gimbal(int16_t vx, int16_t vy, int16_t wz);

motor_measure_t *get_gimbal_motor_measure_point(uint8_t i);
motor_measure_t *get_L_trigger_motor_measure_point(void);
motor_measure_t *get_R_trigger_motor_measure_point(void);
motor_measure_t *get_yaw_gimbal_motor_measure_point(void);
motor_measure_t *get_pitch_gimbal_motor_measure_point(void);
#endif










