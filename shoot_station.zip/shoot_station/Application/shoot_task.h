#ifndef SHOOT_H
#define SHOOT_H

#include "main.h"
#include "can_receive.h"
#include "control_algorithm.h"
#include "bsp_gpio.h"
#include "remote_control.h"
#include "cmsis_os.h"
#include "bsp_pwm.h"

#define SHOOT_SPEED      1000
#define TRIGGER_SPEED    500
//����һ��ת���ĽǶ�
#define PI_THREE                    102144    

typedef enum
{
    SHOOT_STOP = 0,      //��ʼ��
	  SHOOT_READY,         //�����׼��
    SHOOT_BULLET,        //����׼��
    SHOOT_DONE,          //�������
} shoot_mode_e;

typedef struct
{
	rc_info_t *shoot_rc;
	shoot_mode_e shoot_mode;
	
	motor_measure_t *trigger_measure;  //�������
	motor_measure_t *shoot_measure;    //������
	motor_measure_t *yaw_motor;  //yaw����
	
	ramp_function_source_t pull_shoot_ramp;      //
	
	pid_type_def trigger_motor_pid;               
	pid_type_def shoot_pid;
	
	pid_type_def yaw_ecd_pid;
	pid_type_def yaw_speed_pid;
	
	fp32 trigger_speed_set;
	fp32 yaw_speed_set;
	fp32 shoot_speed_set;
	
	fp32 yaw_ecd_set;
	int32_t trigger_ecd_set;
	int32_t trigger_ecd;
	
	int16_t trigger_current;
	int16_t shoot_current;
	int16_t yaw_current;
	
	bool_t move_flag;
	bool_t trigger_flag;
	uint16_t block_time;
} shoot_control_t;	


void shoot_init(void);
void shoot_task(void const * argument);
void shoot_control_loop(void);

void trigger_motor_turn_back(void);
void shoot_bullet_control(void);
int16_t ecd_limit(int16_t ecd);
#endif
