#include "init.h"
#include "bsp_can.h"
#include "bsp_gpio.h"
#include "CAN_receive.h"
#include "remote_control.h"
#include "bsp_pwm.h"
#include "shoot_task.h"

void hw_init(void)
{
	remote_control_init();
  can_filter_init();
	pwm_start();
	power_init();		
}

osThreadId shoot_taskhandle;

void task_init(void)
{

	osThreadDef(SHOOT_TASK, shoot_task, osPriorityNormal, 0, 512);
  shoot_taskhandle = osThreadCreate(osThread(SHOOT_TASK), NULL);

}



